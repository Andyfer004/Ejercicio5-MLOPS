"""Adaptación del Taller 3: reutiliza el paquete original de Champions League.

Instalar antes el repositorio https://github.com/DiegoLinares11/MLFlow.
Esta adaptación debe ejecutarse y validarse en el workspace de Databricks.
"""
import argparse
import json


def ejecutar(experimento, familia='svc', n_iter=40, folds=5, modelo_uc=None):
    import mlflow
    import mlflow.sklearn
    from mlflow import MlflowClient
    from taller3_pipeline.seguimiento import configurar_mlflow, entrenar_familia

    # Sustituye el servidor local que usa por defecto el taller.
    configurar_mlflow(experimento=experimento, uri='databricks')
    mlflow.sklearn.autolog(disable=True)
    resultado = entrenar_familia(familia, n_iter=n_iter, folds=folds, n_jobs=1)
    from taller3_pipeline.data import cargar_datos
    from taller3_pipeline.pipeline import SEED
    from sklearn.metrics import f1_score
    import numpy as np
    import sklearn
    import pandas as pd

    _, X_test, _, y_test = cargar_datos(seed=SEED)
    recargado = mlflow.sklearn.load_model(resultado['model_uri'])
    predicciones = recargado.predict(X_test)
    f1_recargado = float(f1_score(y_test, predicciones, average='macro'))
    np.testing.assert_allclose(f1_recargado, resultado['metricas']['test_f1_macro'])
    with mlflow.start_run(run_id=resultado['run_id']):
        mlflow.log_dict({
            'model_reload_verified': True,
            'test_rows': len(X_test),
            'reloaded_test_f1_macro': f1_recargado,
            'mlflow_version': mlflow.__version__,
            'sklearn_version': sklearn.__version__,
            'pandas_version': pd.__version__,
        }, 'evaluacion/verificacion_recarga.json')
    resultado['recarga_verificada'] = True
    if modelo_uc:
        # Opcional: nombre real catalogo.esquema.modelo y permisos en Unity Catalog.
        mlflow.set_registry_uri('databricks-uc')
        version = mlflow.register_model(resultado['model_uri'], modelo_uc)
        MlflowClient().set_registered_model_alias(modelo_uc, 'campeon', str(version.version))
        resultado['modelo_uc'] = modelo_uc
        resultado['version_uc'] = str(version.version)
    print(json.dumps(resultado, indent=2, ensure_ascii=False, default=str))
    return resultado


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--experimento', required=True, help='Ruta real del experimento en Databricks')
    parser.add_argument('--familia', default='svc')
    parser.add_argument('--n-iter', type=int, default=40)
    parser.add_argument('--folds', type=int, default=5)
    parser.add_argument('--modelo-uc', default=None)
    args = parser.parse_args()
    ejecutar(args.experimento, args.familia, args.n_iter, args.folds, args.modelo_uc)
