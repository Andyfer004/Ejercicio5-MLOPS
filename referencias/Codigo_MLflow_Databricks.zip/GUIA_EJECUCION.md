# Ejecutar y entregar: Champions League + Databricks + GitHub

## 1. Repositorio y archivos

En Databricks: Workspace > tu carpeta de usuario > Create > Git folder. URL: https://github.com/DiegoLinares11/MLFlow.git. Proveedor GitHub. Para publicar cambios necesitas acceso de escritura al repositorio; configura tu cuenta GitHub en la integración Git de Databricks. Si no eres colaborador, usa un fork y su URL.

En la raíz de la carpeta MLFlow, importa Champions_Databricks.ipynb y pipeline_champions_databricks.py desde este ZIP. Conserva las carpetas src/ y los demás archivos originales del repositorio.

## 2. Entorno

Abre el notebook y selecciona un compute de Python con instalación de paquetes habilitada. Copia la ruta absoluta de la carpeta clonada (por ejemplo /Workspace/Users/tu_correo/MLFlow). No copies literalmente el ejemplo: usa la ruta que muestra tu workspace.

En una celda nueva al inicio, para un notebook estándar:

```python
%pip install "mlflow==3.17.1" skops -e "/Workspace/Users/TU_CORREO/MLFlow"
```

Si el entorno solicita reiniciar Python, hazlo antes de ejecutar las celdas del pipeline. En un notebook estándar de Databricks también puedes usar `dbutils.library.restartPython()` en una celda separada. En Git Folder Serverless, las dependencias se gestionan mediante el pyproject.toml del entorno; si la instalación por celda está restringida, configura ahí el paquete y las dependencias equivalentes. No uses un SQL warehouse como compute para este pipeline Python.

## 3. Primera ejecución corta

En la celda de configuración del notebook:

```python
EXPERIMENTO = "/Users/TU_CORREO/Champions_Resultado_Databricks"
resultado = ejecutar(EXPERIMENTO, familia="svc", n_iter=2, folds=3)
resultado
```

Sustituye TU_CORREO por tu usuario real. Ejecuta las celdas de definición antes de esta. Esta prueba corta verifica dependencias e integración, no reproduce la búsqueda completa del taller.

Debe terminar sin errores e imprimir `recarga_verificada: true`. El F1 puede variar respecto del taller. En Experiments, busca el experimento y verifica el run svc, métricas cv_f1_macro y test_f1_macro, datasets de entrenamiento/prueba, modelo y artefactos de evaluación.

## 4. Ejecución completa del notebook

```python
resultado = ejecutar(EXPERIMENTO, familia="svc", n_iter=40, folds=5)
resultado
```

La actividad pide alguna funcionalidad de MLflow; Experiments, Tracking y Models ya se usan sin tener que configurar Feature Store, Unity Catalog o un endpoint. Para repetir toda la comparación del taller, ejecuta también las familias del paquete original (sus claves se consultan con `from taller3_pipeline.modelos import FAMILIAS; print(list(FAMILIAS))`). El trabajo de entrenamiento aumenta al comparar todas.

## 5. Probar el archivo Python

Una forma directa es ejecutar el .py como programa desde una celda del notebook, usando su ruta absoluta. Así se utiliza el mismo entorno ya preparado:

```python
import runpy
import sys

argumentos_previos = sys.argv[:]
try:
    sys.argv = [
        "pipeline_champions_databricks.py",
        "--experimento", EXPERIMENTO,
        "--familia", "svc",
        "--n-iter", "40",
        "--folds", "5",
    ]
    runpy.run_path(
        "/Workspace/Users/TU_CORREO/MLFlow/pipeline_champions_databricks.py",
        run_name="__main__",
    )
finally:
    sys.argv = argumentos_previos
```

Esto ejecuta el punto de entrada real del archivo Python y genera otro run, sin necesidad de crear un Job para la entrega. Si se requiere automatizar, crea un Job con tarea Python script y configura por separado el mismo paquete y dependencias en su entorno; instalarlo en el notebook no lo instala automáticamente en un Job.

## 6. Evidencia y enlace de Databricks

Comprueba: notebook completo sin errores; archivo Python sin errores; al menos un run completo para cada formato; `recarga_verificada: true`; parámetros y métricas; datasets y modelo; `evaluacion/verificacion_recarga.json`. Conserva capturas del run y sus artefactos como evidencia de la ejecución.

En el notebook, Share/Compartir: concede acceso de lectura al docente y copia la URL. El enlace debe abrir el notebook del workspace, no un notebook en GitHub ni el experimento. No es necesario hacer público todo el workspace. Incluye esa URL en la entrega y en el README; úsala para incorporar el vínculo exacto al PDF. Los recursos del workspace no se hacen públicos por compartir su URL.

## 7. Publicar en GitHub

Guarda el notebook ejecutado, el script y el PDF. En el diálogo Git de la carpeta de Databricks, revisa los cambios, escribe `Integra pipeline Champions League con MLflow en Databricks` y usa Commit & Push. Si la rama principal está protegida, crea una rama, publícala y abre un PR para integrarla.

Alternativa: exporta el notebook y usa GitHub > Add file > Upload files con acceso de escritura. Coloca el notebook en notebooks/, el script en la raíz (o documenta la ruta que elijas) y el PDF en reporte/. Agrega al README el enlace de Databricks y un resumen de cómo ejecutar ambos formatos.

Abre el repositorio en GitHub y comprueba que los archivos están en la rama que vas a entregar y que los enlaces abren correctamente. Conserva la procedencia de los resultados del Taller 3; para resultados nuevos usa los que realmente muestre tu ejecución.
